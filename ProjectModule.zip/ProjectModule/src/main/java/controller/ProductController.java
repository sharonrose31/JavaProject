package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ProductDAO;
import model.Product;


@WebServlet("/ProductController")
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
	
		try
		{
		String productId=request.getParameter("prodId");
		String productName=request.getParameter("prodName");
		String productDesc=request.getParameter("description");
		String price=request.getParameter("price");
		String stock=request.getParameter("stock");
		String category=request.getParameter("category");
		String supplier=request.getParameter("supplier");
		
		out.println("Product Id:"+productId);
		out.println("Product name:"+productName);
		out.println("Product Description:"+productDesc);
		out.println("Price:"+price);
		out.println("stock:"+stock);
		out.println("category:"+category);
		out.println("supplier"+supplier);
		
		Product product=new Product(productId,productName,productDesc,price,stock,category,supplier);
		
	   ProductDAO productDAO=new ProductDAO();
		
		if(productDAO.registerProduct(product))
			{
				request.setAttribute("prodName",product.getProductName());
				RequestDispatcher dispatch=request.getRequestDispatcher("ProductHome.jsp");
				dispatch.forward(request, response);
			}
			else
			{
				request.setAttribute("errorInfo","Error Occured During Registering");
				RequestDispatcher dispatch=request.getRequestDispatcher("ErrorPage.jsp");
				dispatch.forward(request, response);
			}
		
		}
		catch(Exception e)
		{
			request.setAttribute("errorInfo","Error Occured During Registering::::"+e.getMessage());
			RequestDispatcher dispatch=request.getRequestDispatcher("ErrorPage.jsp");
			dispatch.forward(request, response);
		}
		
	}
}

